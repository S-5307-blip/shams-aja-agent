// قاعدة بيانات Cloudflare D1 (متوافقة مع SQLite)

export async function markSeen(env, id) {
  const r = await env.DB.prepare('INSERT OR IGNORE INTO seen (wa_id, ts) VALUES (?1, ?2)').bind(id, Date.now()).run();
  return (r.meta?.changes ?? 0) === 1; // true إذا كانت الرسالة جديدة
}

export const addMessage = (env, phone, role, text) =>
  env.DB.prepare('INSERT INTO messages (phone, role, text, ts) VALUES (?1, ?2, ?3, ?4)')
    .bind(phone, role, text, Date.now()).run();

export async function history(env, phone, limit = 12) {
  const { results } = await env.DB.prepare("SELECT role, text FROM messages WHERE phone = ?1 AND role != 'auto' ORDER BY id DESC LIMIT ?2")
    .bind(phone, limit).all();
  return results.reverse();
}

export async function createDraft(env, phone, customerText, reply, analysis) {
  const r = await env.DB.prepare('INSERT INTO drafts (phone, customer_text, reply, analysis, ts) VALUES (?1, ?2, ?3, ?4, ?5)')
    .bind(phone, customerText, reply, JSON.stringify(analysis), Date.now()).run();
  return r.meta.last_row_id;
}

export const getDraft = (env, id) => env.DB.prepare('SELECT * FROM drafts WHERE id = ?1').bind(id).first();
export const setDraftStatus = (env, id, status) =>
  env.DB.prepare('UPDATE drafts SET status = ?1 WHERE id = ?2').bind(status, id).run();

export async function kvGet(env, k) {
  const row = await env.DB.prepare('SELECT v FROM kv WHERE k = ?1').bind(k).first();
  return row?.v ?? null;
}
export const kvSet = (env, k, v) =>
  env.DB.prepare('INSERT INTO kv (k, v) VALUES (?1, ?2) ON CONFLICT(k) DO UPDATE SET v = excluded.v').bind(k, v).run();
export const kvDel = (env, k) => env.DB.prepare('DELETE FROM kv WHERE k = ?1').bind(k).run();

export const optOut = (env, phone) =>
  env.DB.prepare('INSERT OR REPLACE INTO optout (phone, ts) VALUES (?1, ?2)').bind(phone, Date.now()).run();
export async function isOptedOut(env, phone) {
  return !!(await env.DB.prepare('SELECT 1 AS x FROM optout WHERE phone = ?1').bind(phone).first());
}
