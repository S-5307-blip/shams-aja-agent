const endpoint = (env) =>
  `${env.GRAPH_BASE || 'https://graph.facebook.com'}/${env.GRAPH_API_VERSION || 'v24.0'}/${env.WA_PHONE_NUMBER_ID}/messages`;

async function post(env, body) {
  const res = await fetch(endpoint(env), {
    method: 'POST',
    headers: { Authorization: `Bearer ${env.WA_ACCESS_TOKEN}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ messaging_product: 'whatsapp', ...body }),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(`WhatsApp API ${res.status}: ${JSON.stringify(data)}`);
  return data;
}

export const sendText = (env, to, text) =>
  post(env, { to, type: 'text', text: { body: text, preview_url: false } });

// أزرار الرد السريع (حد أقصى 3، وعنوان الزر حتى 20 حرفاً)
export const sendButtons = (env, to, bodyText, buttons) =>
  post(env, {
    to,
    type: 'interactive',
    interactive: {
      type: 'button',
      body: { text: bodyText },
      action: { buttons: buttons.map((b) => ({ type: 'reply', reply: { id: b.id, title: b.title } })) },
    },
  });

export const markRead = (env, messageId) =>
  post(env, { status: 'read', message_id: messageId }).catch(() => {});
