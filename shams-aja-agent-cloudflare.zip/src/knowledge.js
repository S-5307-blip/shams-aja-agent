import knowledge from '../knowledge.json';

export { knowledge };

export const fill = (template, vars = {}) =>
  template.replace(/\{(\w+)\}/g, (_, k) => vars[k] ?? `{${k}}`);
