import * as db from './db.js';
import * as wa from './whatsapp.js';
import { proposeReply } from './agent.js';
import { isOpenNow } from './hours.js';
import { knowledge, fill } from './knowledge.js';

const STOP_WORDS = ['إيقاف', 'ايقاف', 'stop', 'unsubscribe'];
const ACK_COOLDOWN_MS = 6 * 60 * 60 * 1000; // رد خارج الدوام مرة كل 6 ساعات لكل عميل
const norm = (s) => (s || '').trim().toLowerCase();
const ownerOf = (env) => String(env.OWNER_PHONE || '').replace(/\D/g, '');

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);

    if (url.pathname === '/health') return new Response('ok');

    // التحقق من الويب هوك (يطلبه Meta عند الإعداد)
    if (url.pathname === '/webhook' && request.method === 'GET') {
      const ok =
        url.searchParams.get('hub.mode') === 'subscribe' &&
        url.searchParams.get('hub.verify_token') === env.WA_VERIFY_TOKEN;
      return ok ? new Response(url.searchParams.get('hub.challenge')) : new Response('Forbidden', { status: 403 });
    }

    // استقبال الرسائل
    if (url.pathname === '/webhook' && request.method === 'POST') {
      const raw = await request.text();
      if (!(await validSignature(env, raw, request.headers.get('x-hub-signature-256')))) {
        return new Response('Unauthorized', { status: 401 });
      }
      let body;
      try { body = JSON.parse(raw); } catch { return new Response('Bad Request', { status: 400 }); }
      // نرد على Meta فوراً ونكمل المعالجة في الخلفية
      ctx.waitUntil(processPayload(env, body).catch((e) => console.error('payload error', e)));
      return new Response('ok');
    }

    return new Response('Not Found', { status: 404 });
  },
};

// ===================== التحقق من التوقيع (HMAC-SHA256) =====================
async function validSignature(env, raw, header) {
  if (!header || !header.startsWith('sha256=')) return false;
  const key = await crypto.subtle.importKey(
    'raw', new TextEncoder().encode(env.WA_APP_SECRET),
    { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']
  );
  const sig = new Uint8Array(await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(raw)));
  const expected = [...sig].map((b) => b.toString(16).padStart(2, '0')).join('');
  const received = header.slice(7);
  if (received.length !== expected.length) return false;
  let diff = 0; // مقارنة بزمن ثابت
  for (let i = 0; i < expected.length; i++) diff |= expected.charCodeAt(i) ^ received.charCodeAt(i);
  return diff === 0;
}

async function processPayload(env, body) {
  const OWNER = ownerOf(env);
  for (const entry of body?.entry || []) {
    for (const change of entry.changes || []) {
      const value = change.value || {};
      const names = Object.fromEntries((value.contacts || []).map((c) => [c.wa_id, c.profile?.name]));
      for (const m of value.messages || []) {
        if (!(await db.markSeen(env, m.id))) continue; // رسالة مكررة
        try {
          if (m.from === OWNER) await handleOwner(env, m);
          else await handleCustomer(env, m, names[m.from]);
        } catch (e) {
          console.error('handler error', e);
        }
      }
    }
  }
}

function messageText(m) {
  if (m.type === 'text') return m.text?.body ?? null;
  if (m.type === 'interactive') return m.interactive?.button_reply?.title ?? m.interactive?.list_reply?.title ?? null;
  if (m.type === 'button') return m.button?.text ?? null;
  return null;
}

// ===================== رسائل العملاء =====================
async function handleCustomer(env, m, name) {
  const phone = m.from;
  const text = messageText(m);
  await wa.markRead(env, m.id);

  // إيقاف الرسائل التسويقية
  if (text && STOP_WORDS.includes(norm(text))) {
    await db.optOut(env, phone);
    await wa.sendText(env, phone, knowledge.messages.optOutConfirmed);
    await safeOwnerText(env, `ℹ️ العميل +${phone} طلب إيقاف الرسائل التسويقية.`);
    return;
  }

  await db.addMessage(env, phone, 'customer', text ?? `[${m.type}]`);

  // الرد التلقائي الوحيد المعتمد: خارج ساعات العمل (مرة كل 6 ساعات)
  if (!isOpenNow()) {
    const last = Number((await db.kvGet(env, `ack:${phone}`)) || 0);
    if (Date.now() - last > ACK_COOLDOWN_MS) {
      const ack = fill(knowledge.messages.offHours, { hours: knowledge.hours.label });
      await wa.sendText(env, phone, ack);
      await db.addMessage(env, phone, 'auto', ack); // يُسجَّل لكن لا يدخل في سياق Claude
      await db.kvSet(env, `ack:${phone}`, String(Date.now()));
    }
  }

  // صور ومستندات: لا نقرأها، نوجّه العميل للبوابة الآمنة
  if (text === null) {
    const reply = fill(knowledge.messages.documentsGuidance, { portal: knowledge.business.portalUrl });
    const analysis = {
      reply, language: 'ar', customer_type: 'unknown', intent: 'إرسال مستند', confidence: 1,
      handoff: false, summary: `أرسل العميل رسالة من نوع (${m.type}). لم تُقرأ، والمقترح توجيهه للبوابة الآمنة.`,
    };
    const id = await db.createDraft(env, phone, `[${m.type}]`, reply, analysis);
    return notifyOwner(env, id, phone, name, `[${m.type}]`, analysis);
  }

  // تجهيز الرد المقترح
  let analysis;
  try {
    analysis = await proposeReply(env, phone);
  } catch (e) {
    console.error('agent error', e);
    return safeOwnerText(env, `⚠️ تعذّر تجهيز رد تلقائي.\nالعميل: ${name || '—'} (+${phone})\nرسالته: ${text}`);
  }
  const id = await db.createDraft(env, phone, text, analysis.reply, analysis);
  await notifyOwner(env, id, phone, name, text, analysis);
}

async function notifyOwner(env, draftId, phone, name, customerText, a) {
  const head = a.handoff ? `🔔 تحويل إليك: ${a.handoff_reason || 'يحتاج تدخلك'}` : '💬 رد مقترح';
  const body = [
    head,
    `العميل: ${name || '—'} (+${phone})`,
    `رسالته: ${customerText}`,
    '',
    `المقترح: ${a.reply}`,
    '',
    `الملخص: ${a.summary || '—'}`,
    `الثقة: ${Math.round((a.confidence ?? 0) * 100)}%`,
  ].join('\n').slice(0, 1000);
  try {
    await wa.sendButtons(env, ownerOf(env), body, [
      { id: `approve:${draftId}`, title: 'موافقة وإرسال' },
      { id: `edit:${draftId}`, title: 'تعديل' },
      { id: `reject:${draftId}`, title: 'رفض' },
    ]);
  } catch (e) {
    console.error('owner notify failed (غالباً انتهت نافذة 24 ساعة للمالك)', e.message);
  }
}

// ===================== رسائل المالك =====================
async function handleOwner(env, m) {
  const OWNER = ownerOf(env);
  if (m.type === 'interactive' && m.interactive?.button_reply) {
    const [action, idStr] = m.interactive.button_reply.id.split(':');
    const id = Number(idStr);
    const draft = await db.getDraft(env, id);
    if (!draft || draft.status !== 'pending') return wa.sendText(env, OWNER, 'هذا الرد تمت معالجته مسبقاً.');

    if (action === 'approve') return sendToCustomer(env, draft, draft.reply);
    if (action === 'edit') {
      await db.kvSet(env, 'editing', String(id));
      return wa.sendText(env, OWNER, 'اكتب الرد المعدّل وسأرسله للعميل مباشرة. أو أرسل «إلغاء».');
    }
    if (action === 'reject') {
      await db.setDraftStatus(env, id, 'rejected');
      return wa.sendText(env, OWNER, 'تم تجاهل الرد المقترح. يمكنك الرد على العميل مباشرة.');
    }
    return;
  }

  const text = messageText(m);
  if (!text) return;

  const editing = await db.kvGet(env, 'editing');
  if (editing) {
    await db.kvDel(env, 'editing');
    if (norm(text) === 'إلغاء') return wa.sendText(env, OWNER, 'تم الإلغاء.');
    const draft = await db.getDraft(env, Number(editing));
    if (draft && draft.status === 'pending') return sendToCustomer(env, draft, text);
  }
  // أي رسالة أخرى من المالك تُبقي نافذة الـ24 ساعة مفتوحة لاستقبال الإشعارات
  return wa.sendText(env, OWNER, 'جاهز ✅ سأرسل لك الردود المقترحة هنا.');
}

async function sendToCustomer(env, draft, text) {
  try {
    await wa.sendText(env, draft.phone, text);
    await db.addMessage(env, draft.phone, 'business', text);
    await db.setDraftStatus(env, draft.id, 'sent');
    await wa.sendText(env, ownerOf(env), '✅ أُرسل للعميل.');
  } catch (e) {
    console.error('send failed', e.message);
    await safeOwnerText(env, '⚠️ تعذّر الإرسال، غالباً انتهت نافذة الـ24 ساعة للعميل. استخدم قالباً معتمداً أو رد عليه من التطبيق.');
  }
}

async function safeOwnerText(env, text) {
  try { await wa.sendText(env, ownerOf(env), text); } catch (e) { console.error('owner text failed', e.message); }
}
